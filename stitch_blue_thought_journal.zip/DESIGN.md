# Design System Document

## 1. Overview & Creative North Star: "The Intellectual Atelier"
This design system moves away from the generic "blog template" and toward a high-end editorial experience. The Creative North Star is **The Intellectual Atelier**: a space that feels curated, academic, and profoundly calm. 

Instead of rigid grids and heavy borders, the system utilizes **Intentional Asymmetry** and **Tonal Depth**. By leveraging wide margins, overlapping typographic elements, and a "paper-on-glass" layering philosophy, we create a digital environment that prioritizes the "Deep Reading" state. It is professional enough for analytical philosophy, yet fluid enough for modern web interactions.

---

## 2. Colors & Surface Philosophy
The palette is a sophisticated range of blues and greys designed to provide "visual silence," allowing the content to lead.

### Surface Hierarchy & Nesting
We reject the flat web. Hierarchy is established through **Tonal Layering**. Use the `surface-container` tiers to create a sense of physical stacking.
- **The Base:** Always start with `surface` (#fbf9f9) or `surface-container-lowest` (#ffffff).
- **The Layer:** Place `surface-container-low` (#f5f3f3) elements on top of the base to create a soft, natural lift.
- **The Focus:** Use `primary-container` (#307ca0) for high-impact callouts, creating a "recessed" or "elevated" feel through color weight rather than lines.

### The "No-Line" Rule
**Prohibit the use of 1px solid borders for sectioning.** 
Structural boundaries must be defined solely through background color shifts or generous whitespace. If you feel the need to draw a line, instead shift the background of that section to `surface-container` (#efeded).

### Signature Textures & Glass
- **The "Glass & Gradient" Rule:** For mobile navigation bars or floating "To Top" buttons, use `surface` with 80% opacity and a `backdrop-filter: blur(12px)`. This creates a high-end "frosted glass" effect that keeps the user grounded in the content.
- **Atmospheric Gradients:** Use a subtle linear gradient from `primary` (#016386) to `primary-container` (#307ca0) for Hero headers to add "soul" and depth that prevents the design from feeling clinical.

---

## 3. Typography: The Editorial Voice
Our typography balances the authority of a journal with the accessibility of a modern blog.

| Level | Token | Font Family | Size | Intent |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | **Work Sans** | 3.5rem | High-impact headlines; use with tight letter-spacing. |
| **Headline**| `headline-md` | **Work Sans** | 1.75rem | Section starts; bold and assertive. |
| **Title** | `title-lg` | **Newsreader** | 1.375rem | Article titles in feeds; evokes a literary feel. |
| **Body** | `body-lg` | **Newsreader** | 1rem | The primary reading experience. Optimized for long-form Turkish. |
| **Label** | `label-md` | **Inter** | 0.75rem | Metadata (Date, Author, Category). |

**Editorial Note:** Always pair a `display` heading in Work Sans (Modern/Sans) with `body` text in Newsreader (Classic/Serif). This contrast is the signature of the "Intellectual Atelier."

---

## 4. Elevation & Depth
We define space through light and tone, never through heavy shadows.

- **The Layering Principle:** Stack `surface-container-lowest` cards on a `surface-dim` background. This creates a "paper on stone" effect.
- **Ambient Shadows:** Standard drop shadows are forbidden. When elevation is required (e.g., a floating menu), use an extra-diffused shadow: `box-shadow: 0 12px 40px rgba(0, 30, 44, 0.06)`. Note the use of a blue-tinted shadow (`on-primary-fixed`) to maintain color harmony.
- **The "Ghost Border" Fallback:** If a border is functionally required for form fields, use `outline-variant` (#bfc8ce) at **20% opacity**. It should be felt, not seen.

---

## 5. Components

### Buttons (The "Tactile" Approach)
- **Primary:** `primary` (#016386) background with `on-primary` (#ffffff) text. Use `lg` (0.5rem) roundedness.
- **Secondary:** `secondary-container` (#b0e0ff) background. No border.
- **Tertiary:** No background. Text in `primary`. Hover state uses a `surface-container-high` subtle fill.

### Cards & Feed Items
- **Rule:** **No Dividers.** Separate articles in a list using 48px–64px of vertical whitespace. 
- **Style:** Use a `surface-container-lowest` card with a `sm` (0.125rem) radius for a sharp, "architectural" look.

### Input Fields
- **Background:** `surface-container-high` (#e9e8e7).
- **Indicator:** A 2px bottom-bar in `primary` that expands on focus. Avoid full-box outlines to maintain the minimal aesthetic.

### Chips (Taxonomy)
- Use `secondary-fixed-dim` (#9dcdeb) for category tags. Typography should be `label-md` in all caps with +0.05em letter spacing for an "archival" look.

### The "Reading Progress" Component (Contextual)
- A 2px height bar at the very top of the viewport using the `primary` color, tracking the scroll depth. Essential for the academic/long-form persona.

---

## 6. Do’s and Don’ts

### Do
- **Do** use generous white space (margins of 15-20% on desktop) to center the reader’s focus.
- **Do** use `Newsreader` for any text longer than two sentences to prevent eye fatigue.
- **Do** use "Turkish-specific" typesetting: Ensure line heights (`leading`) are 1.6x for body text to accommodate Turkish diacritics (ç, ğ, ı, ö, ş, ü).

### Don't
- **Don't** use pure black (#000000) for text. Use `on-surface` (#1b1c1c) for better readability and a premium feel.
- **Don't** use standard "Material Design" shadows. They are too heavy for this editorial style.
- **Don't** use 100% width for text blocks. Cap article width at 720px for the "sweet spot" of readability.
- **Don't** use cards with heavy borders. Let the content breathe.